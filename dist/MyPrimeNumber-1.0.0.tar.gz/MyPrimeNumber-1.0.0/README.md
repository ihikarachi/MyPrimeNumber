# MyPrimeNumber

Developed by Shakeel Abbas from imam Hussain (a.s) institute Karachi (c) 2023

## Examples of How To Use 

```python
from MyPrimeNumber import isPrimeNumber
from MyPrimeNumber import primeNumberList

x = isPrimeNumber(17)
print (x)

lst = PrimeNumberList(2,200)
print (lst)

```


Check out: https://www.youtube.com/@imamHussainasinstitute
from .code import isPrimeNumber
from .code import primeNumberList

